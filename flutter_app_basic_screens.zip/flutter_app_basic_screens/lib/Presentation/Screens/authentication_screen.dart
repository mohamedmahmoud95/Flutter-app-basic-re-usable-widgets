import 'package:flutter/material.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/registration_screen.dart';

import '../../Constants/Constants.dart';
import 'login_screen.dart';

class AuthenticationScreen extends StatefulWidget {
  const AuthenticationScreen({Key? key}) : super(key: key);

  @override
  _AuthenticationScreenState createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen> {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: mainBlue,
            title: const Text('Welcome to basics app'),
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.login), text: "Login"),
                Tab(icon: Icon(Icons.app_registration), text: "Register"),
              ],
            ),
          ),


          body:  const TabBarView(
            children: [
              LoginScreen(),
              RegistrationScreen(),

            ],
          ),
        ),
      ),
    );
  }
}


