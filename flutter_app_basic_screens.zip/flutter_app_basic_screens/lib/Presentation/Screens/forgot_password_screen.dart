import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/login_screen.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/registration_screen.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/reset_password_screen.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/authentication_screen.dart';

import '../../Constants/Constants.dart';
import '../reusable_widgets/button_widget.dart';


class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({Key? key}) : super(key: key);

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

final TextEditingController emailController = TextEditingController();
final TextEditingController passwordController = TextEditingController();

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {

  @override
  Widget build(BuildContext context) {
    String resetPasswordCode = "1234";

    String enteredResetPasswordCode = "";
    final emailField = TextFormField(
        controller: emailController,
        keyboardType: TextInputType.emailAddress,
        onSaved: (value) {
          emailController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.email_outlined),
          contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10),
          label: Text("Email Address"),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ));


    final resetPasswordCodeField = TextFormField(
        controller: passwordController,
        obscureText: true,
        onChanged: (enteredResetPasswordCode) {
          passwordController.text = enteredResetPasswordCode;
           enteredResetPasswordCode = enteredResetPasswordCode;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          //prefixIcon: Icon(Icons.code),

          contentPadding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          label: const Text("Reset password code"),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ));

    final loginButton = Material(
      elevation: 5,
      borderRadius: BorderRadius.circular(30),
      color: Colors.red,
      child: MaterialButton(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
        onPressed: () {
          // Navigator.push(context, MaterialPageRoute(builder: (context) =>
          //     HomeScreen()));
        },
        child: const Text(
          "Login",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white
          ),
        ),
      ),
    );
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: mainBlue,
        title: const Text("Forgot password? it's ok"),
        leading: const BackButton(),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[

                  const SizedBox(height: defaultSpacing),
                  emailField,

                  const SizedBox(height: defaultSpacing),
                  ButtonWidget(text: 'Enter', onClicked: () {},),

                  const SizedBox(height: defaultSpacing),
                  const SizedBox(height: defaultSpacing),

                  const SizedBox(height: defaultSpacing),
                  const Text('Enter the 4 digits code sent to you email'),

                  const SizedBox(height: defaultSpacing/2),




                      Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget> [
                      const Text("Did not receive a reset code? "),
                      GestureDetector(
                      onTap:() {
                        // Navigator.push(context, MaterialPageRoute(builder: (context) =>
                        // const ForgotPasswordScreen()));
                        print("resending reset code to user email");
                      },

                      child: const Text("Resend",
                      style: TextStyle(
                      color: Colors.redAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 15
                      ),
                        ),
                      ),
                  ],
                      ),
                  const SizedBox(height: defaultSpacing),

                  resetPasswordCodeField,
                  const SizedBox(height: defaultSpacing),


                  ButtonWidget(text: 'Reset password', onClicked: () {
                    if (enteredResetPasswordCode == resetPasswordCode) {
                      Navigator.push(
                          context, MaterialPageRoute(builder: (context) =>
                      const ResetPasswordScreen()));
                    }
                    else
                      {
                        print ("wrong reset code!");
                     //show snack bar
                      }
                    //if condition is not working for some reason!
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) =>
                    const ResetPasswordScreen()));
                  },),
                ],
              )


          ),
        ),
      ),
    );
  }
}