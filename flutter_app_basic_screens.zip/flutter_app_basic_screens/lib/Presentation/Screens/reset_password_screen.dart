import 'package:flutter/material.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/login_screen.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/registration_screen.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/authentication_screen.dart';

import '../../Constants/Constants.dart';
import '../reusable_widgets/button_widget.dart';


class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({Key? key}) : super(key: key);

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

final TextEditingController emailController = TextEditingController();
final TextEditingController passwordController = TextEditingController();

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  @override
  Widget build(BuildContext context) {

    final newPasswordField = TextFormField(
        controller: passwordController,
        obscureText: true,
        onSaved: (value) {
          passwordController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          prefixIcon: const Icon(Icons.key),

          contentPadding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          label: const Text("New password"),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ));

    final confirmNewPasswordField = TextFormField(
        controller: passwordController,
        obscureText: true,
        onSaved: (value) {
          passwordController.text = value!;
        },
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.key),

          contentPadding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          label: const Text("Confirm new password"),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ));







    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: mainBlue,
        title: const Text('Reset password'),
        leading: BackButton(),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[

                  const Text('You can not reset your password'),

                  const SizedBox(height: defaultSpacing ),


                  const SizedBox(height: defaultSpacing * 1),
                  newPasswordField,
                  const SizedBox(height: defaultSpacing * 1),
                  confirmNewPasswordField,

                  const SizedBox(height: defaultSpacing * 1.5),

                  ButtonWidget(text: 'Submit', onClicked: () {
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) =>
                    const AuthenticationScreen()));
                  },),

                ],
              )


          ),
        ),
      ),
    );
  }
}