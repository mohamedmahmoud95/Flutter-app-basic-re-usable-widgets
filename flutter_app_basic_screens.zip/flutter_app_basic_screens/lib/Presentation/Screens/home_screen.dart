import 'package:flutter/material.dart';
import 'package:flutter_app_basic_screens/Presentation/Screens/registration_screen.dart';

import '../../Constants/Constants.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            leading: Icon (Icons.menu),
            backgroundColor: mainBlue,
            title: const Text('Home screen'),
          ),


          body: Center(child: Text("This is home screen")),

        ),
      ),
    );
  }
}


