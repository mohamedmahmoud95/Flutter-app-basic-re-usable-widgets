import 'package:flutter/material.dart';


//-------------------------------------------------------------//
//colors
const Color primaryColor = Color(0xFFF67952);
const Color secondaryColor = Color.fromARGB(55, 8, 12, 44);
const Color bgColor = Color.fromARGB(255, 253, 251, 252);
const Color mainBlack = Color.fromRGBO(43, 46, 44, 1);
const Color mainWhite = Color.fromRGBO(240, 240, 240, 1);
const Color mainOrange = Color.fromRGBO(255, 198, 0, 1);
//const Color mainBlue = Color.fromRGBO(32, 87, 114,1);
const Color mainBlue = Color(0xFF042B59);

//-------------------------------------------------------------//




//-------------------------------------------------------------//
//measures
const double defaultPadding = 16.0;
const double defaultBorderRadius = 12.0;
const double defaultSpacing = 20 ;
//-------------------------------------------------------------//
