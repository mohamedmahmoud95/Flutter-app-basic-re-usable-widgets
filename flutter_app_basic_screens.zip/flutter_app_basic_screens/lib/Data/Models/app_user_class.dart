class AppUser {
 String firstName ;
 String lastName ;
 String userName;
 String password;
 String email;
 String phoneNumber;
 int? age;
 String? country;
 String? address;
 String? profilePictureURL;


 AppUser({
   required this.firstName,
   required this.lastName,
   required this.userName,
   required this.password,
   required this.email,
   required this.phoneNumber,
});

}


AppUser sampleAppUser1 = AppUser(firstName: 'Mohamed', lastName: 'Mahmoud', userName: 'mohamed95',  phoneNumber: '+201001412578', email: 'm.raslan97@gmail.com', password: '123456', );
AppUser sampleAppUser2 = AppUser(firstName: 'Ali',     lastName: 'Osama',   userName: 'AliOsama1',  phoneNumber: '+201234567891', email: 'ali0sama11@gmail.com', password: '123456', );
AppUser sampleAppUser3 = AppUser(firstName: 'Mariam',  lastName: 'Seif',    userName: 'Mariam2000', phoneNumber: '+201098765432', email: 'mariamSeif@gmail.com', password: '123456', );

//a list of sample app users to iterate over for authentication
List <AppUser> sampleAppUsers = [sampleAppUser1, sampleAppUser2,sampleAppUser3];