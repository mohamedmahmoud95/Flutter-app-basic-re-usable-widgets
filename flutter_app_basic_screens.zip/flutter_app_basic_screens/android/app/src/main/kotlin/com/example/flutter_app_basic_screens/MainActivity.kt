package com.example.flutter_app_basic_screens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
